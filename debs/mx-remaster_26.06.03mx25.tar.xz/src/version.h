inline const QString VERSION {"26.06.03mx25"};
